MIRUTA RC55 — NAVEGACIÓN INTEGRADA

Sube TODO el contenido de esta carpeta a la raíz del repositorio:
- index.html
- bitacora-de-trabajo.html
- fondo-app.png
- manifest.webmanifest
- sw.js
- carpeta assets completa

IMPORTANTE:
1. No cambies los nombres.
2. La carpeta assets/leaflet es necesaria para el mapa.
3. La navegación calcula rutas nuevas con conexión móvil.
4. Miruta mantiene la ruta en el orden exacto de las viñetas.
5. El modo de ubicación continua depende de que la PWA permanezca activa en iPhone; el GPS nativo en segundo plano llegará con la app iOS nativa.
