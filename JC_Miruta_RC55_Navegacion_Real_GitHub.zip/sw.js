const CACHE='miruta-rc55-nav-v1';
const CORE=[
  './','./index.html','./fondo-app.png','./manifest.webmanifest','./sw.js',
  './assets/leaflet/leaflet.css','./assets/leaflet/leaflet.js','./assets/sortable.min.js',
  './assets/leaflet/images/marker-icon.png','./assets/leaflet/images/marker-icon-2x.png','./assets/leaflet/images/marker-shadow.png'
];
self.addEventListener('install',e=>e.waitUntil(caches.open(CACHE).then(c=>c.addAll(CORE)).then(()=>self.skipWaiting())));
self.addEventListener('activate',e=>e.waitUntil(caches.keys().then(keys=>Promise.all(keys.filter(k=>k!==CACHE).map(k=>caches.delete(k)))).then(()=>self.clients.claim())));
self.addEventListener('fetch',e=>{
  if(e.request.method!=='GET') return;
  const url=new URL(e.request.url);
  if(url.origin!==location.origin){
    // Map tiles and route resources are runtime-cached after the first successful use.
    e.respondWith(caches.match(e.request).then(cached=>cached||fetch(e.request).then(r=>{
      if(r.ok){const copy=r.clone();caches.open(CACHE).then(c=>c.put(e.request,copy));}
      return r;
    }).catch(()=>new Response('',{status:503,statusText:'Offline'}))));
    return;
  }
  if(e.request.mode==='navigate'){
    e.respondWith(fetch(e.request).then(r=>{const copy=r.clone();caches.open(CACHE).then(c=>c.put('./index.html',copy));return r}).catch(()=>caches.match('./index.html'))); return;
  }
  e.respondWith(caches.match(e.request).then(cached=>cached||fetch(e.request).then(r=>{if(r.ok){const copy=r.clone();caches.open(CACHE).then(c=>c.put(e.request,copy));}return r}).catch(()=>caches.match('./index.html'))));
});
