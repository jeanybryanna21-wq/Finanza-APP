MIRUTA RC56 — GPS 100% INTERNO EN LA INTERFAZ

Sube TODO el contenido de esta carpeta a la raíz del repositorio y REEMPLAZA los archivos anteriores:
- index.html
- bitacora-de-trabajo.html
- fondo-app.png
- manifest.webmanifest
- sw.js
- carpeta assets completa

IMPORTANTE EN IPHONE DESPUÉS DE SUBIR:
1. Abre la URL normal del sitio en Safari.
2. Recarga la página una vez con datos/Wi‑Fi.
3. Cierra Miruta desde el selector de apps y vuelve a abrirla.
4. Si la app instalada sigue mostrando una versión vieja, elimina el icono PWA y vuelve a usar Compartir > Añadir a pantalla de inicio.

RC56 elimina los enlaces de navegación a Apple Maps y Google Maps de los tickets. Tocar una dirección, el botón GPS, GO o "Iniciar ruta completa" abre el navegador INTERNO de Miruta.

La búsqueda de direcciones, teselas del mapa y cálculo de rutas nuevas requieren conexión móvil. La interfaz de navegación permanece dentro de Miruta.
